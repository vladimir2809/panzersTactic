var panzerOption = [
    {
        width:25,
        height:25,
        bodyNameImage: 'body11',
        towerNameImage: 'tower11',
        mixTowerX:3.5,// �������� �����
        mixTowerY: 7.5,
        mixTowerPosX:13,
        mixTowerPosY:13,
        speed:15,
        maxHP:80,
        DMG:20,
    },
    {
        width:29,
        height:29,
        bodyNameImage: 'body12',
        towerNameImage: 'tower12',
        mixTowerX:6.5,// �������� �����
        mixTowerY: 18.5,
        mixTowerPosX:14.5,
        mixTowerPosY:14.5,
        speed:10,
        maxHP:100,
        DMG:35,
    },
    {
        width:35,
        height:35,
        bodyNameImage: 'body13',
        towerNameImage: 'tower13',
        mixTowerX:8.5,// �������� �����
        mixTowerY: 18.5,
        mixTowerPosX:17,
        mixTowerPosY:17,
        speed:7,
        maxHP:150,
        DMG:50,
    },
    
]